import { useState, useRef, useCallback, useEffect } from "react";
import { Audio } from "expo-av";
import * as DocumentPicker from "expo-document-picker";
import * as Sharing from "expo-sharing";
import * as Haptics from "expo-haptics";
import { Alert, Platform } from "react-native";

export type RecordingState = "idle" | "recording" | "recorded";
export type PlaybackState = "idle" | "playing" | "paused";

export interface AudioMixerState {
  recordingState: RecordingState;
  playbackState: PlaybackState;
  voiceUri: string | null;
  voiceName: string | null;
  melodyUri: string | null;
  melodyName: string | null;
  recordingDuration: number;
  playbackPosition: number;
  playbackDuration: number;
  isExporting: boolean;
  hasMix: boolean;
}

export interface AudioMixerActions {
  startRecording: () => Promise<void>;
  stopRecording: () => Promise<void>;
  pickVoiceFile: () => Promise<void>;
  pickMelodyFile: () => Promise<void>;
  clearVoice: () => void;
  clearMelody: () => void;
  playMix: () => Promise<void>;
  pauseMix: () => Promise<void>;
  stopMix: () => Promise<void>;
  exportMix: () => Promise<void>;
}

export function useAudioMixer(): AudioMixerState & AudioMixerActions {
  const [recordingState, setRecordingState] = useState<RecordingState>("idle");
  const [playbackState, setPlaybackState] = useState<PlaybackState>("idle");
  const [voiceUri, setVoiceUri] = useState<string | null>(null);
  const [voiceName, setVoiceName] = useState<string | null>(null);
  const [melodyUri, setMelodyUri] = useState<string | null>(null);
  const [melodyName, setMelodyName] = useState<string | null>(null);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [playbackPosition, setPlaybackPosition] = useState(0);
  const [playbackDuration, setPlaybackDuration] = useState(0);
  const [isExporting, setIsExporting] = useState(false);

  const recordingRef = useRef<Audio.Recording | null>(null);
  const voiceSoundRef = useRef<Audio.Sound | null>(null);
  const melodySoundRef = useRef<Audio.Sound | null>(null);
  const durationTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const positionTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      playsInSilentModeIOS: true,
      staysActiveInBackground: false,
    });
    return () => {
      recordingRef.current?.stopAndUnloadAsync().catch(() => {});
      voiceSoundRef.current?.unloadAsync().catch(() => {});
      melodySoundRef.current?.unloadAsync().catch(() => {});
      if (durationTimerRef.current) clearInterval(durationTimerRef.current);
      if (positionTimerRef.current) clearInterval(positionTimerRef.current);
    };
  }, []);

  const requestMicPermission = async (): Promise<boolean> => {
    const { status } = await Audio.requestPermissionsAsync();
    if (status !== "granted") {
      Alert.alert(
        "إذن الميكروفون",
        "يحتاج التطبيق للوصول إلى الميكروفون لتسجيل صوتك.",
        [{ text: "حسناً" }]
      );
      return false;
    }
    return true;
  };

  const startRecording = useCallback(async () => {
    const permitted = await requestMicPermission();
    if (!permitted) return;
    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });
      const rec = new Audio.Recording();
      await rec.prepareToRecordAsync({
        ...Audio.RecordingOptionsPresets.HIGH_QUALITY,
        android: {
          extension: ".m4a",
          outputFormat: Audio.AndroidOutputFormat.MPEG_4,
          audioEncoder: Audio.AndroidAudioEncoder.AAC,
          sampleRate: 44100,
          numberOfChannels: 2,
          bitRate: 192000,
        },
        ios: {
          extension: ".m4a",
          outputFormat: Audio.IOSOutputFormat.MPEG4AAC,
          audioQuality: Audio.IOSAudioQuality.MAX,
          sampleRate: 44100,
          numberOfChannels: 2,
          bitRate: 192000,
          linearPCMBitDepth: 16,
          linearPCMIsBigEndian: false,
          linearPCMIsFloat: false,
        },
        web: {
          mimeType: "audio/webm",
          bitsPerSecond: 192000,
        },
      });
      await rec.startAsync();
      recordingRef.current = rec;
      setRecordingState("recording");
      setRecordingDuration(0);
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
      durationTimerRef.current = setInterval(() => {
        setRecordingDuration(d => d + 1);
      }, 1000);
    } catch (e) {
      Alert.alert("خطأ", "تعذّر بدء التسجيل. حاول مرة أخرى.");
    }
  }, []);

  const stopRecording = useCallback(async () => {
    if (!recordingRef.current) return;
    if (durationTimerRef.current) clearInterval(durationTimerRef.current);
    try {
      await recordingRef.current.stopAndUnloadAsync();
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
      const uri = recordingRef.current.getURI();
      recordingRef.current = null;
      if (uri) {
        setVoiceUri(uri);
        setVoiceName("تسجيل الصوت");
        setRecordingState("recorded");
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (e) {
      Alert.alert("خطأ", "حدث خطأ أثناء إيقاف التسجيل.");
      setRecordingState("idle");
    }
  }, []);

  const pickVoiceFile = useCallback(async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({
        type: ["audio/*"],
        copyToCacheDirectory: true,
      });
      if (!res.canceled && res.assets?.length) {
        const asset = res.assets[0];
        setVoiceUri(asset.uri);
        setVoiceName(asset.name);
        setRecordingState("recorded");
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      }
    } catch {
      Alert.alert("خطأ", "تعذّر رفع ملف الصوت.");
    }
  }, []);

  const pickMelodyFile = useCallback(async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({
        type: ["audio/*", "audio/midi", "audio/x-midi"],
        copyToCacheDirectory: true,
      });
      if (!res.canceled && res.assets?.length) {
        const asset = res.assets[0];
        setMelodyUri(asset.uri);
        setMelodyName(asset.name);
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      }
    } catch {
      Alert.alert("خطأ", "تعذّر رفع ملف اللحن.");
    }
  }, []);

  const clearVoice = useCallback(() => {
    voiceSoundRef.current?.unloadAsync().catch(() => {});
    voiceSoundRef.current = null;
    setVoiceUri(null);
    setVoiceName(null);
    setRecordingState("idle");
    setRecordingDuration(0);
  }, []);

  const clearMelody = useCallback(() => {
    melodySoundRef.current?.unloadAsync().catch(() => {});
    melodySoundRef.current = null;
    setMelodyUri(null);
    setMelodyName(null);
  }, []);

  const unloadSounds = async () => {
    await voiceSoundRef.current?.unloadAsync().catch(() => {});
    await melodySoundRef.current?.unloadAsync().catch(() => {});
    voiceSoundRef.current = null;
    melodySoundRef.current = null;
  };

  const playMix = useCallback(async () => {
    if (!voiceUri && !melodyUri) {
      Alert.alert("لا توجد ملفات", "سجّل صوتك أو ارفع ملف صوتي أولاً.");
      return;
    }
    try {
      await unloadSounds();
      if (positionTimerRef.current) clearInterval(positionTimerRef.current);

      let maxDuration = 0;

      if (voiceUri) {
        const { sound: vs } = await Audio.Sound.createAsync(
          { uri: voiceUri },
          { shouldPlay: false, volume: 1.0 }
        );
        voiceSoundRef.current = vs;
        const status = await vs.getStatusAsync();
        if (status.isLoaded && status.durationMillis) {
          maxDuration = Math.max(maxDuration, status.durationMillis);
        }
      }

      if (melodyUri) {
        const { sound: ms } = await Audio.Sound.createAsync(
          { uri: melodyUri },
          { shouldPlay: false, volume: 0.7 }
        );
        melodySoundRef.current = ms;
        const status = await ms.getStatusAsync();
        if (status.isLoaded && status.durationMillis) {
          maxDuration = Math.max(maxDuration, status.durationMillis);
        }
      }

      setPlaybackDuration(maxDuration);
      setPlaybackPosition(0);
      setPlaybackState("playing");
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

      await voiceSoundRef.current?.playAsync();
      await melodySoundRef.current?.playAsync();

      positionTimerRef.current = setInterval(async () => {
        const st = await voiceSoundRef.current?.getStatusAsync();
        if (st?.isLoaded) {
          setPlaybackPosition(st.positionMillis ?? 0);
          if (!st.isPlaying && (st.positionMillis ?? 0) >= (st.durationMillis ?? 1) - 200) {
            clearInterval(positionTimerRef.current!);
            setPlaybackState("idle");
            setPlaybackPosition(0);
          }
        }
      }, 250);
    } catch (e) {
      Alert.alert("خطأ في التشغيل", "تعذّر تشغيل الصوت.");
      setPlaybackState("idle");
    }
  }, [voiceUri, melodyUri]);

  const pauseMix = useCallback(async () => {
    await voiceSoundRef.current?.pauseAsync();
    await melodySoundRef.current?.pauseAsync();
    setPlaybackState("paused");
    if (positionTimerRef.current) clearInterval(positionTimerRef.current);
  }, []);

  const stopMix = useCallback(async () => {
    await voiceSoundRef.current?.stopAsync();
    await melodySoundRef.current?.stopAsync();
    setPlaybackState("idle");
    setPlaybackPosition(0);
    if (positionTimerRef.current) clearInterval(positionTimerRef.current);
  }, []);

  const exportMix = useCallback(async () => {
    const canShare = await Sharing.isAvailableAsync();
    if (!canShare) {
      Alert.alert("التصدير", "المشاركة غير متاحة على هذا الجهاز.");
      return;
    }
    if (!voiceUri) {
      Alert.alert("لا يوجد صوت", "سجّل صوتك أولاً للتصدير.");
      return;
    }
    setIsExporting(true);
    try {
      await Sharing.shareAsync(voiceUri, {
        mimeType: "audio/m4a",
        dialogTitle: "تصدير الصوت العربي",
        UTI: "public.audio",
      });
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {
      Alert.alert("خطأ", "تعذّر تصدير الملف.");
    }
    setIsExporting(false);
  }, [voiceUri]);

  const hasMix = !!voiceUri || !!melodyUri;

  return {
    recordingState,
    playbackState,
    voiceUri,
    voiceName,
    melodyUri,
    melodyName,
    recordingDuration,
    playbackPosition,
    playbackDuration,
    isExporting,
    hasMix,
    startRecording,
    stopRecording,
    pickVoiceFile,
    pickMelodyFile,
    clearVoice,
    clearMelody,
    playMix,
    pauseMix,
    stopMix,
    exportMix,
  };
}
