import React, { useState, useCallback, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { PipelineStageCard } from "@/components/PipelineStageCard";

const PIPELINE_STAGES = [
  { id: "encoder",     label: "Voice Encoder",      sub: "ECAPA-TDNN / WavLM",    icon: "🎙️" },
  { id: "phonemes",    label: "Arabic Phonemes",    sub: "MFA + CAMeL Tools",     icon: "🔤" },
  { id: "melody",      label: "Melody Extraction",  sub: "RMVPE + CREPE",         icon: "🎵" },
  { id: "maqam",       label: "Maqam Intelligence", sub: "Neural Scale Detector", icon: "🎼" },
  { id: "emotion",     label: "Emotion Engine",     sub: "Affect Transfer",       icon: "💫" },
  { id: "ornament",    label: "Ornamentation",      sub: "Tarab Generator",       icon: "🌀" },
  { id: "synthesis",   label: "Neural Synthesis",   sub: "DiffSinger + VITS",     icon: "⚙️" },
  { id: "postprocess", label: "Post Processing",    sub: "Studio EQ + Reverb",    icon: "✨" },
];

const STAGE_MESSAGES: Record<string, string> = {
  encoder:     "تحليل البصمة الصوتية...",
  phonemes:    "استخراج مخارج الحروف العربية...",
  melody:      "رسم منحنى اللحن...",
  maqam:       "تطبيق المقام العربي...",
  emotion:     "ضخ الطاقة العاطفية...",
  ornament:    "توليد العُرب والزخارف...",
  synthesis:   "تركيب الصوت العصبي...",
  postprocess: "معالجة الإنتاج النهائي...",
};

type Status = "idle" | "active" | "done" | "error";

interface LogEntry {
  msg: string;
  type: "info" | "success" | "warning" | "error";
  time: string;
}

export default function PipelineScreen() {
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === "web" ? 34 : 0;

  const [pipelineStatus, setPipelineStatus] = useState<Record<string, Status>>({});
  const [pipelineProgress, setPipelineProgress] = useState<Record<string, number>>({});
  const [processingLog, setProcessingLog] = useState<LogEntry[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const addLog = (msg: string, type: LogEntry["type"] = "info") => {
    setProcessingLog(prev => [
      ...prev.slice(-30),
      { msg, type, time: new Date().toLocaleTimeString("ar") },
    ]);
  };

  const runPipeline = useCallback(async () => {
    if (isRunning) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsRunning(true);
    setProcessingLog([]);
    setPipelineStatus({});
    setPipelineProgress({});
    addLog("بدء معالجة المحرك العصبي العربي...", "info");

    for (const stage of PIPELINE_STAGES) {
      setPipelineStatus(prev => ({ ...prev, [stage.id]: "active" }));
      addLog(STAGE_MESSAGES[stage.id], "info");

      for (let p = 0; p <= 100; p += 10) {
        setPipelineProgress(prev => ({ ...prev, [stage.id]: p }));
        await new Promise<void>(r => setTimeout(r, 40 + Math.random() * 30));
      }
      setPipelineProgress(prev => ({ ...prev, [stage.id]: 100 }));
      setPipelineStatus(prev => ({ ...prev, [stage.id]: "done" }));
      addLog(`✓ ${stage.label} اكتمل`, "success");
      await new Promise<void>(r => setTimeout(r, 60));
    }

    addLog("🎵 الصوت العربي جاهز للاستماع!", "success");
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setIsRunning(false);
  }, [isRunning]);

  const logColors: Record<string, string> = {
    info: "#555",
    success: "#2E8B7A",
    warning: "#C8963E",
    error: "#A84444",
  };

  return (
    <View style={[styles.container]}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 + bottom }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Stages */}
        <View style={styles.card}>
          <Text style={styles.cardLabel}>⚙️ مراحل المعالجة</Text>
          <View style={{ gap: 6 }}>
            {PIPELINE_STAGES.map(s => (
              <PipelineStageCard
                key={s.id}
                stage={s}
                status={pipelineStatus[s.id] ?? "idle"}
                progress={pipelineProgress[s.id] ?? 0}
              />
            ))}
          </View>
        </View>

        {/* Log */}
        <View style={styles.card}>
          <Text style={styles.cardLabel}>📋 سجل العمليات</Text>
          <View style={styles.logBox}>
            {processingLog.length === 0 ? (
              <Text style={styles.emptyLog}>لم تبدأ المعالجة بعد</Text>
            ) : (
              processingLog.map((l, i) => (
                <View key={i} style={styles.logRow}>
                  <Text style={styles.logTime}>[{l.time}]</Text>
                  <Text style={[styles.logMsg, { color: logColors[l.type] }]}>{l.msg}</Text>
                </View>
              ))
            )}
          </View>
        </View>

        {/* Run button */}
        <TouchableOpacity
          onPress={runPipeline}
          disabled={isRunning}
          activeOpacity={0.8}
          style={[styles.runBtn, { opacity: isRunning ? 0.5 : 1 }]}
        >
          <Feather name={isRunning ? "loader" : "play"} size={16} color="#C8963E" />
          <Text style={styles.runBtnText}>
            {isRunning ? "جاري التشغيل..." : "تشغيل خط المعالجة"}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#070709" },
  content: { padding: 16 },
  card: { backgroundColor: "#0d0d12", borderWidth: 1, borderColor: "#1a1a22", borderRadius: 12, padding: 14, marginBottom: 12 },
  cardLabel: { fontSize: 11, color: "#666", marginBottom: 12 },
  logBox: { minHeight: 160 },
  emptyLog: { color: "#333", textAlign: "center", marginTop: 60 },
  logRow: { flexDirection: "row", gap: 8, marginBottom: 3 },
  logTime: { color: "#333", fontSize: 9, flexShrink: 0 },
  logMsg: { fontSize: 9, flex: 1 },
  runBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#C8963E18", borderWidth: 1, borderColor: "#C8963E44", borderRadius: 12, padding: 14 },
  runBtnText: { color: "#C8963E", fontSize: 13 },
});
