import { BlurView } from "expo-blur";
import { Tabs } from "expo-router";
import { Feather } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View } from "react-native";
import { useColors } from "@/hooks/useColors";

export default function TabLayout() {
  const colors = useColors();
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: "#C8963E",
        tabBarInactiveTintColor: "#444",
        headerStyle: { backgroundColor: "#070709" },
        headerTintColor: "#e0d4c0",
        headerShadowVisible: false,
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : "#0a0a0f",
          borderTopWidth: 1,
          borderTopColor: "#1a1a22",
          elevation: 0,
          height: isWeb ? 84 : 60,
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} />
          ) : isWeb ? (
            <View style={[StyleSheet.absoluteFill, { backgroundColor: "#0a0a0f" }]} />
          ) : null,
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: "600",
          marginBottom: isWeb ? 6 : 2,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "الاستوديو",
          headerTitle: "طرب AI · الاستوديو",
          tabBarIcon: ({ color }) => <Feather name="mic" size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="pipeline"
        options={{
          title: "المعالجة",
          headerTitle: "خط المعالجة",
          tabBarIcon: ({ color }) => <Feather name="cpu" size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="maqam"
        options={{
          title: "المقامات",
          headerTitle: "المقامات العربية",
          tabBarIcon: ({ color }) => <Feather name="disc" size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="ai"
        options={{
          title: "تحليل ذكي",
          headerTitle: "تحليل الذكاء الاصطناعي",
          tabBarIcon: ({ color }) => <Feather name="zap" size={22} color={color} />,
        }}
      />
    </Tabs>
  );
}
