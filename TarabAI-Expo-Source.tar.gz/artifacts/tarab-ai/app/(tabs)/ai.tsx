import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

const MAQAMAT = [
  { id: "bayati",   name: "بياتي" },
  { id: "hijaz",    name: "حجاز" },
  { id: "rast",     name: "راست" },
  { id: "saba",     name: "صبا" },
  { id: "sikah",    name: "سيكا" },
  { id: "nahawand", name: "نهاوند" },
  { id: "ajam",     name: "عجم" },
];

const EMOTIONS = [
  { id: "huzn",   name: "حزن" },
  { id: "shajan", name: "شجن" },
  { id: "hamasa", name: "حماسة" },
  { id: "hana",   name: "هناء" },
  { id: "quwa",   name: "قوة" },
  { id: "huduu",  name: "هدوء" },
];

const ARCHITECTURE = `core/
 ├── voice_encoder/      ← ECAPA-TDNN · WavLM
 ├── arabic_phonemes/    ← MFA · CAMeL · Farasa
 ├── melody_engine/      ← RMVPE · CREPE · librosa
 ├── pitch_mapper/       ← pyworld · F0 extraction
 ├── maqam_ai/           ← Neural scale detector
 ├── emotion_ai/         ← Affect transfer model
 ├── ornamentation/      ← Tarab generator
 ├── synthesis/          ← DiffSinger · VITS · RVC
 ├── post_processing/    ← EQ · Reverb · Mastering
 └── export/             ← WAV · FLAC · MP3`;

const SAMPLE_ANALYSIS = `1. المقام المناسب: مقام البياتي
يناسب هذا النص لما فيه من الشوق والحنين لليلة العيد والاحتفال، والبياتي هو أكثر المقامات تعبيراً عن المشاعر الوجدانية المختلطة.

2. العاطفة الغالبة: الشجن الممزوج بالفرح
النص يجمع بين الحنين والفرح معاً، مما يجعله من أصعب الأداءات تعبيراً.

3. أسلوب التطريب المناسب: أسلوب أم كلثوم
مع اهتمام بالتمطيط والعُرب في كلمة "ليلة" و"انستينا"، والتنفس الطويل.

4. الزخارف الصوتية المقترحة:
• ميلزمة على "ليلة" تصاعدية
• تثليث في "العيد" بنبرة احتفالية
• تحلية ختامية في "انستينا"

5. طريقة الأداء الأمثل:
البدء بصوت رخيم منخفض ثم الصعود تدريجياً مع التعبير عن الفرح في الشطر الثاني.`;

export default function AIScreen() {
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === "web" ? 34 : 0;

  const [arabicText, setArabicText] = useState("يا ليلة العيد انستينا");
  const [selectedMaqam, setSelectedMaqam] = useState("bayati");
  const [selectedEmotion, setSelectedEmotion] = useState("shajan");
  const [aiAnalysis, setAiAnalysis] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyze = async () => {
    if (!arabicText.trim()) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsAnalyzing(true);
    setAiAnalysis("");
    await new Promise<void>(r => setTimeout(r, 2000 + Math.random() * 1000));
    const maqamName = MAQAMAT.find(m => m.id === selectedMaqam)?.name ?? "";
    const emotionName = EMOTIONS.find(e => e.id === selectedEmotion)?.name ?? "";
    setAiAnalysis(
      `تحليل: "${arabicText}"\nالمقام المختار: ${maqamName} · العاطفة: ${emotionName}\n\n` + SAMPLE_ANALYSIS
    );
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setIsAnalyzing(false);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 + bottom }]}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      {/* Input */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>تحليل ذكاء اصطناعي للنص الغنائي</Text>
        <TextInput
          value={arabicText}
          onChangeText={setArabicText}
          multiline
          numberOfLines={4}
          textAlign="right"
          style={styles.textInput}
          placeholder="اكتب كلمات الأغنية للتحليل..."
          placeholderTextColor="#333"
        />

        {/* Selectors */}
        <View style={styles.selectorRow}>
          <View style={styles.selector}>
            <Text style={styles.selectorLabel}>المقام</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.chipRow}>
                {MAQAMAT.map(m => (
                  <TouchableOpacity
                    key={m.id}
                    onPress={() => setSelectedMaqam(m.id)}
                    style={[styles.chip, { borderColor: selectedMaqam === m.id ? "#C8963E" : "#1a1a22",
                      backgroundColor: selectedMaqam === m.id ? "#C8963E18" : "transparent" }]}
                  >
                    <Text style={{ color: selectedMaqam === m.id ? "#C8963E" : "#555", fontSize: 11 }}>{m.name}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>
          <View style={styles.selector}>
            <Text style={styles.selectorLabel}>العاطفة</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.chipRow}>
                {EMOTIONS.map(e => (
                  <TouchableOpacity
                    key={e.id}
                    onPress={() => setSelectedEmotion(e.id)}
                    style={[styles.chip, { borderColor: selectedEmotion === e.id ? "#9B4E8E" : "#1a1a22",
                      backgroundColor: selectedEmotion === e.id ? "#9B4E8E18" : "transparent" }]}
                  >
                    <Text style={{ color: selectedEmotion === e.id ? "#cc88dd" : "#555", fontSize: 11 }}>{e.name}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>
        </View>

        <TouchableOpacity
          onPress={analyze}
          disabled={isAnalyzing}
          activeOpacity={0.8}
          style={[styles.analyzeBtn, { opacity: isAnalyzing ? 0.6 : 1 }]}
        >
          {isAnalyzing ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Feather name="search" size={16} color="#fff" />
          )}
          <Text style={styles.analyzeBtnText}>
            {isAnalyzing ? "يحلل..." : "تحليل النص الغنائي"}
          </Text>
        </TouchableOpacity>
      </View>

      {/* AI Response */}
      {(aiAnalysis || isAnalyzing) && (
        <View style={styles.responseCard}>
          <Text style={styles.responseHeader}>💡 تحليل المحرك العصبي</Text>
          {isAnalyzing ? (
            <View style={styles.loadingRow}>
              {[0, 1, 2].map(i => (
                <View key={i} style={[styles.dot, { opacity: 0.5 + i * 0.25 }]} />
              ))}
              <Text style={styles.loadingText}>يحلل الخصائص الموسيقية...</Text>
            </View>
          ) : (
            <Text style={styles.responseText}>{aiAnalysis}</Text>
          )}
        </View>
      )}

      {/* Architecture */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>🏗️ معمارية النظام</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <Text style={styles.archText}>{ARCHITECTURE}</Text>
        </ScrollView>
      </View>

      {/* Info */}
      <View style={styles.infoCard}>
        <Feather name="info" size={14} color="#3A86A8" style={{ marginBottom: 6 }} />
        <Text style={styles.infoText}>
          هذا تطبيق عرض توضيحي لمحرك الغناء العربي العصبي. التحليل الذكي مدمج في التطبيق ويعمل بدون اتصال.
        </Text>
        <Text style={styles.poweredBy}>
          TarabAI · DiffSinger · VITS · Arabic NLP Stack
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#070709" },
  content: { padding: 16 },
  card: { backgroundColor: "#0d0d12", borderWidth: 1, borderColor: "#1a1a22", borderRadius: 12, padding: 14, marginBottom: 12 },
  cardLabel: { fontSize: 11, color: "#666", marginBottom: 10 },
  textInput: { backgroundColor: "#070709", borderWidth: 1, borderColor: "#1a1a22", borderRadius: 8, color: "#e0d4c0", fontSize: 15, padding: 10, minHeight: 90, textAlignVertical: "top", marginBottom: 10 },
  selectorRow: { gap: 8, marginBottom: 10 },
  selector: { gap: 4 },
  selectorLabel: { fontSize: 10, color: "#444" },
  chipRow: { flexDirection: "row", gap: 6 },
  chip: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 16, borderWidth: 1 },
  analyzeBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#3A86A8", borderRadius: 8, padding: 12, marginTop: 4 },
  analyzeBtnText: { color: "#fff", fontSize: 13, fontWeight: "600" },
  responseCard: { backgroundColor: "#0d0d12", borderWidth: 1, borderColor: "#3A86A844", borderRadius: 12, padding: 14, marginBottom: 12 },
  responseHeader: { fontSize: 11, color: "#3A86A8", marginBottom: 10 },
  loadingRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#3A86A8" },
  loadingText: { fontSize: 11, color: "#555" },
  responseText: { fontSize: 13, color: "#ccc", lineHeight: 22, textAlign: "right" },
  archText: { fontFamily: Platform.OS === "ios" ? "Courier" : "monospace", fontSize: 10, color: "#444", lineHeight: 18 },
  infoCard: { backgroundColor: "#3A86A808", borderWidth: 1, borderColor: "#3A86A822", borderRadius: 12, padding: 14, marginBottom: 12, alignItems: "center" },
  infoText: { fontSize: 11, color: "#666", textAlign: "center", lineHeight: 18, marginBottom: 8 },
  poweredBy: { fontSize: 9, color: "#333", letterSpacing: 0.5 },
});
