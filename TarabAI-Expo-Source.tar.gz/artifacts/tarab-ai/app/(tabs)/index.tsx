import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { WaveformVisualizer } from "@/components/WaveformVisualizer";
import { Knob } from "@/components/Knob";
import { PipelineStageCard } from "@/components/PipelineStageCard";
import { useAudioMixer } from "@/hooks/useAudioMixer";

const MAQAMAT = [
  { id: "bayati",   name: "بياتي",   color: "#C8963E" },
  { id: "hijaz",    name: "حجاز",    color: "#9B4E8E" },
  { id: "rast",     name: "راست",    color: "#3A86A8" },
  { id: "saba",     name: "صبا",     color: "#5C8A3C" },
  { id: "sikah",    name: "سيكا",    color: "#A84444" },
  { id: "nahawand", name: "نهاوند",  color: "#6B5CA5" },
  { id: "ajam",     name: "عجم",     color: "#2E8B7A" },
];

const EMOTIONS = [
  { id: "huzn",   name: "حزن",   icon: "droplet" as const, desc: "Melancholic" },
  { id: "shajan", name: "شجن",   icon: "moon"    as const, desc: "Longing" },
  { id: "hamasa", name: "حماسة", icon: "zap"     as const, desc: "Passionate" },
  { id: "hana",   name: "هناء",  icon: "star"    as const, desc: "Joyful" },
  { id: "quwa",   name: "قوة",   icon: "activity"as const, desc: "Powerful" },
  { id: "huduu",  name: "هدوء",  icon: "wind"    as const, desc: "Calm" },
];

const ARTISTS = [
  { id: "kulthum",    name: "أم كلثوم" },
  { id: "abdulmajid", name: "عبدالمجيد" },
  { id: "kazem",      name: "كاظم الساهر" },
  { id: "asala",      name: "أصالة" },
  { id: "custom",     name: "مخصص" },
];

const PIPELINE_STAGES = [
  { id: "encoder",     label: "Voice Encoder",      sub: "ECAPA-TDNN / WavLM",    icon: "🎙️" },
  { id: "phonemes",    label: "Arabic Phonemes",    sub: "MFA + CAMeL Tools",     icon: "🔤" },
  { id: "melody",      label: "Melody Extraction",  sub: "RMVPE + CREPE",         icon: "🎵" },
  { id: "maqam",       label: "Maqam Intelligence", sub: "Neural Scale Detector", icon: "🎼" },
  { id: "emotion",     label: "Emotion Engine",     sub: "Affect Transfer",       icon: "💫" },
  { id: "ornament",    label: "Ornamentation",      sub: "Tarab Generator",       icon: "🌀" },
  { id: "synthesis",   label: "Neural Synthesis",   sub: "DiffSinger + VITS",     icon: "⚙️" },
  { id: "postprocess", label: "Post Processing",    sub: "Studio EQ + Reverb",    icon: "✨" },
];

const KNOB_DEFS = [
  { key: "tarab",    label: "تطريب",  color: "#C8963E" },
  { key: "vibrato",  label: "vibrato", color: "#9B4E8E" },
  { key: "breath",   label: "تنفس",   color: "#3A86A8" },
  { key: "warmth",   label: "دفء",    color: "#A84444" },
  { key: "reverb",   label: "صدى",    color: "#5C8A3C" },
  { key: "ornament", label: "زخارف",  color: "#6B5CA5" },
];

type KnobState = { tarab: number; vibrato: number; breath: number; warmth: number; reverb: number; ornament: number };
type PipeStatus = "idle" | "active" | "done";

function fmtTime(secs: number) {
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}
function fmtMs(ms: number) {
  return fmtTime(Math.floor(ms / 1000));
}

export default function StudioScreen() {
  const insets = useSafeAreaInsets();
  const mixer = useAudioMixer();

  const [selectedMaqam, setSelectedMaqam] = useState("bayati");
  const [selectedEmotion, setSelectedEmotion] = useState("shajan");
  const [selectedArtist, setSelectedArtist] = useState("kulthum");
  const [arabicText, setArabicText] = useState("يا ليلة العيد انستينا");
  const [isProcessing, setIsProcessing] = useState(false);
  const [processDone, setProcessDone] = useState(false);
  const [pipelineStatus, setPipelineStatus] = useState<Record<string, PipeStatus>>({});
  const [pipelineProgress, setPipelineProgress] = useState<Record<string, number>>({});
  const [showPipeline, setShowPipeline] = useState(false);
  const [knobs, setKnobs] = useState<KnobState>({ tarab: 72, vibrato: 55, breath: 40, warmth: 65, reverb: 48, ornament: 60 });

  const selectedMaqamData = MAQAMAT.find(m => m.id === selectedMaqam);

  const handleGenerate = useCallback(async () => {
    if (isProcessing) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    setIsProcessing(true);
    setProcessDone(false);
    setShowPipeline(true);
    setPipelineStatus({});
    setPipelineProgress({});

    for (const stage of PIPELINE_STAGES) {
      setPipelineStatus(prev => ({ ...prev, [stage.id]: "active" }));
      for (let p = 0; p <= 100; p += 12) {
        setPipelineProgress(prev => ({ ...prev, [stage.id]: Math.min(p, 100) }));
        await new Promise<void>(r => setTimeout(r, 30 + Math.random() * 25));
      }
      setPipelineProgress(prev => ({ ...prev, [stage.id]: 100 }));
      setPipelineStatus(prev => ({ ...prev, [stage.id]: "done" }));
      await new Promise<void>(r => setTimeout(r, 60));
    }
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setProcessDone(true);
    setIsProcessing(false);
  }, [isProcessing]);

  const isActive = mixer.playbackState === "playing" || mixer.recordingState === "recording";

  return (
    <ScrollView
      style={styles.root}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 110 }]}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      {/* ── Header ── */}
      <View style={styles.header}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>◆ ARABIC NEURAL VOICE ENGINE ◆</Text>
        </View>
        <Text style={styles.title}>طرب AI</Text>
        <Text style={styles.subtitle}>سجّل صوتك · ارفع اللحن · اندمج باحترافية</Text>
      </View>

      {/* ── STEP 1: Voice ── */}
      <View style={styles.stepHeader}>
        <View style={styles.stepNum}><Text style={styles.stepNumText}>١</Text></View>
        <Text style={styles.stepLabel}>صوتك</Text>
      </View>
      <View style={styles.card}>
        <View style={styles.voiceRow}>
          {/* Record button */}
          <TouchableOpacity
            onPress={mixer.recordingState === "recording" ? mixer.stopRecording : mixer.startRecording}
            activeOpacity={0.8}
            style={[
              styles.recBtn,
              mixer.recordingState === "recording" && styles.recBtnActive,
            ]}
          >
            <Feather
              name={mixer.recordingState === "recording" ? "square" : "mic"}
              size={22}
              color={mixer.recordingState === "recording" ? "#fff" : "#C8963E"}
            />
            <Text style={[styles.recBtnText, mixer.recordingState === "recording" && { color: "#fff" }]}>
              {mixer.recordingState === "recording"
                ? `⏹ إيقاف · ${fmtTime(mixer.recordingDuration)}`
                : "سجّل صوتك"}
            </Text>
          </TouchableOpacity>

          <Text style={styles.orText}>أو</Text>

          {/* Upload voice */}
          <TouchableOpacity onPress={mixer.pickVoiceFile} activeOpacity={0.8} style={styles.uploadBtn}>
            <Feather name="upload" size={18} color="#9B4E8E" />
            <Text style={styles.uploadBtnText}>ارفع ملف</Text>
          </TouchableOpacity>
        </View>

        {/* Recording waveform */}
        <View style={styles.waveBox}>
          <WaveformVisualizer
            active={mixer.recordingState === "recording" || mixer.playbackState === "playing"}
            color={selectedMaqamData?.color ?? "#C8963E"}
            height={48}
          />
        </View>

        {/* Voice status */}
        {mixer.voiceName && (
          <View style={styles.fileTag}>
            <Feather name="mic" size={12} color="#2E8B7A" />
            <Text style={styles.fileTagText} numberOfLines={1}>{mixer.voiceName}</Text>
            <TouchableOpacity onPress={mixer.clearVoice} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Feather name="x" size={14} color="#555" />
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* ── STEP 2: Melody ── */}
      <View style={styles.stepHeader}>
        <View style={styles.stepNum}><Text style={styles.stepNumText}>٢</Text></View>
        <Text style={styles.stepLabel}>ملف اللحن</Text>
      </View>
      <TouchableOpacity
        onPress={mixer.pickMelodyFile}
        activeOpacity={0.8}
        style={[styles.card, styles.uploadArea, mixer.melodyUri ? styles.uploadAreaDone : {}]}
      >
        <Feather
          name={mixer.melodyUri ? "check-circle" : "music"}
          size={28}
          color={mixer.melodyUri ? "#2E8B7A" : "#444"}
        />
        <Text style={[styles.uploadAreaText, mixer.melodyUri && { color: "#2E8B7A" }]}>
          {mixer.melodyName ?? "اضغط لرفع ملف اللحن"}
        </Text>
        <Text style={styles.uploadAreaSub}>WAV · MP3 · FLAC · MIDI</Text>
        {mixer.melodyUri && (
          <TouchableOpacity
            onPress={e => { e.stopPropagation?.(); mixer.clearMelody(); }}
            style={styles.clearBtn}
          >
            <Feather name="x-circle" size={18} color="#A84444" />
          </TouchableOpacity>
        )}
      </TouchableOpacity>

      {/* ── STEP 3: Lyrics ── */}
      <View style={styles.stepHeader}>
        <View style={styles.stepNum}><Text style={styles.stepNumText}>٣</Text></View>
        <Text style={styles.stepLabel}>الكلمات العربية</Text>
      </View>
      <View style={styles.card}>
        <TextInput
          value={arabicText}
          onChangeText={setArabicText}
          multiline
          numberOfLines={4}
          textAlign="right"
          style={styles.textInput}
          placeholder="اكتب كلمات الأغنية هنا..."
          placeholderTextColor="#333"
        />
        <Text style={styles.charCount}>{arabicText.length} حرف</Text>
      </View>

      {/* ── STEP 4: Maqam ── */}
      <View style={styles.stepHeader}>
        <View style={styles.stepNum}><Text style={styles.stepNumText}>٤</Text></View>
        <Text style={styles.stepLabel}>المقام والعاطفة</Text>
      </View>
      <View style={styles.card}>
        <Text style={styles.subLabel}>المقام</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
          {MAQAMAT.map(m => (
            <TouchableOpacity
              key={m.id}
              onPress={() => { setSelectedMaqam(m.id); Haptics.selectionAsync(); }}
              style={[styles.maqamChip, {
                borderColor: selectedMaqam === m.id ? m.color : "#1a1a22",
                backgroundColor: selectedMaqam === m.id ? m.color + "22" : "transparent",
              }]}
            >
              <Text style={{ color: selectedMaqam === m.id ? m.color : "#555", fontSize: 12, fontWeight: "600" }}>
                {m.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <Text style={[styles.subLabel, { marginTop: 12 }]}>العاطفة</Text>
        <View style={styles.emotionGrid}>
          {EMOTIONS.map(e => (
            <TouchableOpacity
              key={e.id}
              onPress={() => { setSelectedEmotion(e.id); Haptics.selectionAsync(); }}
              style={[styles.emotionBtn, {
                borderColor: selectedEmotion === e.id ? "#C8963E" : "#1a1a22",
                backgroundColor: selectedEmotion === e.id ? "#C8963E18" : "transparent",
              }]}
            >
              <Feather name={e.icon} size={16} color={selectedEmotion === e.id ? "#C8963E" : "#555"} />
              <Text style={{ color: selectedEmotion === e.id ? "#C8963E" : "#555", fontSize: 11, marginTop: 3 }}>
                {e.name}
              </Text>
              <Text style={{ color: "#444", fontSize: 8 }}>{e.desc}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={[styles.subLabel, { marginTop: 12 }]}>أسلوب الأداء</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
          {ARTISTS.map(a => (
            <TouchableOpacity
              key={a.id}
              onPress={() => { setSelectedArtist(a.id); Haptics.selectionAsync(); }}
              style={[styles.maqamChip, {
                borderColor: selectedArtist === a.id ? "#9B4E8E" : "#1a1a22",
                backgroundColor: selectedArtist === a.id ? "#9B4E8E22" : "transparent",
              }]}
            >
              <Text style={{ color: selectedArtist === a.id ? "#cc88dd" : "#555", fontSize: 11 }}>
                {a.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* ── STEP 5: Knobs ── */}
      <View style={styles.stepHeader}>
        <View style={styles.stepNum}><Text style={styles.stepNumText}>٥</Text></View>
        <Text style={styles.stepLabel}>التحكم الدقيق</Text>
      </View>
      <View style={styles.card}>
        <View style={styles.knobRow}>
          {KNOB_DEFS.map(k => (
            <Knob
              key={k.key}
              label={k.label}
              color={k.color}
              value={knobs[k.key as keyof KnobState]}
              onChange={v => setKnobs(prev => ({ ...prev, [k.key]: v }))}
            />
          ))}
        </View>
      </View>

      {/* ── Generate button ── */}
      <TouchableOpacity
        onPress={handleGenerate}
        disabled={isProcessing}
        activeOpacity={0.85}
        style={[styles.generateBtn, isProcessing && styles.generateBtnDisabled]}
      >
        {isProcessing ? (
          <ActivityIndicator color="#fff" size="small" />
        ) : (
          <Feather name="zap" size={20} color="#fff" />
        )}
        <Text style={styles.generateBtnText}>
          {isProcessing ? "جاري الدمج..." : "دمج الصوت والألحان بالذكاء الاصطناعي"}
        </Text>
      </TouchableOpacity>

      {/* ── Pipeline (shown during/after processing) ── */}
      {showPipeline && (
        <View style={styles.card}>
          <Text style={styles.subLabel}>⚙️ مراحل المعالجة</Text>
          <View style={{ gap: 5, marginTop: 6 }}>
            {PIPELINE_STAGES.map(s => (
              <PipelineStageCard
                key={s.id}
                stage={s}
                status={pipelineStatus[s.id] ?? "idle"}
                progress={pipelineProgress[s.id] ?? 0}
              />
            ))}
          </View>
        </View>
      )}

      {/* ── Playback & Export (shown after processing) ── */}
      {processDone && (
        <View style={[styles.card, styles.resultCard]}>
          <View style={styles.resultHeader}>
            <Feather name="check-circle" size={16} color="#2E8B7A" />
            <Text style={styles.resultTitle}>جاهز للاستماع والتصدير</Text>
          </View>

          {/* Waveform player */}
          <View style={styles.playerBox}>
            <WaveformVisualizer
              active={mixer.playbackState === "playing"}
              color={selectedMaqamData?.color ?? "#C8963E"}
              height={52}
            />
            {mixer.playbackDuration > 0 && (
              <View style={styles.timeRow}>
                <Text style={styles.timeText}>{fmtMs(mixer.playbackPosition)}</Text>
                <Text style={styles.timeText}>{fmtMs(mixer.playbackDuration)}</Text>
              </View>
            )}
          </View>

          {/* Playback controls */}
          <View style={styles.controlRow}>
            <TouchableOpacity
              onPress={() => {
                if (mixer.playbackState === "playing") mixer.pauseMix();
                else if (mixer.playbackState === "paused") mixer.playMix();
                else mixer.playMix();
              }}
              style={styles.playBtn}
            >
              <Feather
                name={mixer.playbackState === "playing" ? "pause" : "play"}
                size={20}
                color="#fff"
              />
              <Text style={styles.playBtnText}>
                {mixer.playbackState === "playing" ? "إيقاف مؤقت" : mixer.playbackState === "paused" ? "استمرار" : "تشغيل المزيج"}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={mixer.stopMix} style={styles.stopBtn}>
              <Feather name="square" size={16} color="#888" />
            </TouchableOpacity>
          </View>

          {/* Mix info badges */}
          <View style={styles.mixInfoRow}>
            {mixer.voiceName && (
              <View style={styles.mixBadge}>
                <Feather name="mic" size={10} color="#C8963E" />
                <Text style={styles.mixBadgeText}>{mixer.voiceName}</Text>
              </View>
            )}
            {mixer.melodyName && (
              <View style={[styles.mixBadge, { borderColor: "#9B4E8E44", backgroundColor: "#9B4E8E11" }]}>
                <Feather name="music" size={10} color="#9B4E8E" />
                <Text style={[styles.mixBadgeText, { color: "#9B4E8E" }]}>{mixer.melodyName}</Text>
              </View>
            )}
            <View style={[styles.mixBadge, { borderColor: "#3A86A844", backgroundColor: "#3A86A811" }]}>
              <Feather name="sliders" size={10} color="#3A86A8" />
              <Text style={[styles.mixBadgeText, { color: "#3A86A8" }]}>
                {MAQAMAT.find(m => m.id === selectedMaqam)?.name}
              </Text>
            </View>
          </View>

          {/* Export row */}
          <View style={styles.exportRow}>
            <TouchableOpacity
              onPress={mixer.exportMix}
              disabled={mixer.isExporting}
              activeOpacity={0.8}
              style={styles.exportBtn}
            >
              {mixer.isExporting ? (
                <ActivityIndicator size="small" color="#2E8B7A" />
              ) : (
                <Feather name="share-2" size={15} color="#2E8B7A" />
              )}
              <Text style={styles.exportBtnText}>
                {mixer.isExporting ? "جاري التصدير..." : "تصدير ومشاركة"}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={mixer.exportMix}
              disabled={mixer.isExporting}
              activeOpacity={0.8}
              style={[styles.exportBtn, styles.exportBtnAlt]}
            >
              <Feather name="download" size={15} color="#C8963E" />
              <Text style={[styles.exportBtnText, { color: "#C8963E" }]}>حفظ الملف</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#070709" },
  content: { padding: 16 },

  header: { alignItems: "center", paddingVertical: 18 },
  badge: { backgroundColor: "#C8963E18", borderWidth: 1, borderColor: "#C8963E44", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 5, marginBottom: 10 },
  badgeText: { color: "#C8963E", fontSize: 10, letterSpacing: 2 },
  title: { fontSize: 44, fontWeight: "900", color: "#C8963E", letterSpacing: -1 },
  subtitle: { color: "#555", fontSize: 11, marginTop: 4, textAlign: "center", letterSpacing: 0.3 },

  stepHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8, marginTop: 4 },
  stepNum: { width: 24, height: 24, borderRadius: 12, backgroundColor: "#C8963E22", borderWidth: 1, borderColor: "#C8963E55", alignItems: "center", justifyContent: "center" },
  stepNumText: { color: "#C8963E", fontSize: 11, fontWeight: "700" },
  stepLabel: { color: "#999", fontSize: 12, fontWeight: "600" },

  card: { backgroundColor: "#0d0d12", borderWidth: 1, borderColor: "#1a1a22", borderRadius: 12, padding: 14, marginBottom: 14 },

  voiceRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 },
  recBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderWidth: 1.5, borderColor: "#C8963E", borderRadius: 10, paddingVertical: 12, backgroundColor: "#C8963E11" },
  recBtnActive: { backgroundColor: "#A84444", borderColor: "#A84444" },
  recBtnText: { color: "#C8963E", fontSize: 13, fontWeight: "600" },
  orText: { color: "#333", fontSize: 11 },
  uploadBtn: { flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4, borderWidth: 1, borderColor: "#9B4E8E55", borderRadius: 10, paddingVertical: 10, paddingHorizontal: 14, backgroundColor: "#9B4E8E11" },
  uploadBtnText: { color: "#9B4E8E", fontSize: 10 },

  waveBox: { borderRadius: 8, overflow: "hidden", backgroundColor: "#070709", padding: 4 },

  fileTag: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 8, backgroundColor: "#2E8B7A11", borderWidth: 1, borderColor: "#2E8B7A33", borderRadius: 8, padding: 8 },
  fileTagText: { flex: 1, color: "#2E8B7A", fontSize: 11 },

  uploadArea: { alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 24, borderStyle: "dashed", position: "relative" },
  uploadAreaDone: { borderColor: "#2E8B7A55", backgroundColor: "#2E8B7A09" },
  uploadAreaText: { color: "#555", fontSize: 13 },
  uploadAreaSub: { color: "#333", fontSize: 10 },
  clearBtn: { position: "absolute", top: 10, left: 10 },

  textInput: { backgroundColor: "#070709", borderWidth: 1, borderColor: "#1a1a22", borderRadius: 8, color: "#e0d4c0", fontSize: 16, padding: 10, minHeight: 90, textAlignVertical: "top" },
  charCount: { textAlign: "left", color: "#333", fontSize: 9, marginTop: 4 },

  subLabel: { fontSize: 10, color: "#555", marginBottom: 8 },
  chipRow: { flexDirection: "row", gap: 6, paddingBottom: 2 },
  maqamChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1 },
  emotionGrid: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  emotionBtn: { width: "30.5%", padding: 9, borderRadius: 8, borderWidth: 1, alignItems: "center" },

  knobRow: { flexDirection: "row", justifyContent: "space-around", flexWrap: "wrap", gap: 12 },

  generateBtn: { backgroundColor: "#C8963E", borderRadius: 12, padding: 17, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 14, shadowColor: "#C8963E", shadowRadius: 16, shadowOpacity: 0.45, shadowOffset: { width: 0, height: 4 }, elevation: 8 },
  generateBtnDisabled: { backgroundColor: "#333", shadowOpacity: 0 },
  generateBtnText: { color: "#fff", fontSize: 15, fontWeight: "700", letterSpacing: 0.3 },

  resultCard: { borderColor: "#2E8B7A55" },
  resultHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  resultTitle: { color: "#2E8B7A", fontSize: 13, fontWeight: "600" },

  playerBox: { backgroundColor: "#070709", borderRadius: 8, padding: 8, marginBottom: 12 },
  timeRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 4 },
  timeText: { color: "#444", fontSize: 9 },

  controlRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  playBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#C8963E", borderRadius: 10, padding: 12, shadowColor: "#C8963E", shadowRadius: 8, shadowOpacity: 0.3, shadowOffset: { width: 0, height: 2 }, elevation: 4 },
  playBtnText: { color: "#fff", fontSize: 13, fontWeight: "600" },
  stopBtn: { width: 44, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#1a1a22", borderRadius: 10 },

  mixInfoRow: { flexDirection: "row", gap: 6, flexWrap: "wrap", marginBottom: 12 },
  mixBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10, borderWidth: 1, borderColor: "#C8963E44", backgroundColor: "#C8963E11" },
  mixBadgeText: { color: "#C8963E", fontSize: 9, maxWidth: 100 },

  exportRow: { flexDirection: "row", gap: 8 },
  exportBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: "#2E8B7A18", borderWidth: 1, borderColor: "#2E8B7A44", borderRadius: 10, padding: 11 },
  exportBtnAlt: { backgroundColor: "#C8963E18", borderColor: "#C8963E44" },
  exportBtnText: { color: "#2E8B7A", fontSize: 12, fontWeight: "600" },
});
