import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";

import { MaqamWheel } from "@/components/MaqamWheel";
import { WaveformVisualizer } from "@/components/WaveformVisualizer";

const MAQAMAT = [
  { id: "bayati",   name: "بياتي",   color: "#C8963E", freq: 261.63, feel: "الشوق والحنين، الطابع الشرقي الأصيل" },
  { id: "hijaz",    name: "حجاز",    color: "#9B4E8E", freq: 293.66, feel: "الحزن والتأمل، طابع تركي مميز" },
  { id: "rast",     name: "راست",    color: "#3A86A8", freq: 329.63, feel: "الاتزان والهدوء، مقام الفرح المعتدل" },
  { id: "saba",     name: "صبا",     color: "#5C8A3C", freq: 349.23, feel: "الحزن العميق والبكاء، أحزن المقامات" },
  { id: "sikah",    name: "سيكا",    color: "#A84444", freq: 392.00, feel: "الحب والرومانسية، دفء خاص" },
  { id: "nahawand", name: "نهاوند",  color: "#6B5CA5", freq: 440.00, feel: "الشجن الغربي، يشبه السلم الصغير" },
  { id: "ajam",     name: "عجم",     color: "#2E8B7A", freq: 493.88, feel: "الفرح والانشراح، طابع غربي" },
];

const TAGS = ["درجة القرار", "التأثير العاطفي", "الاستخدام الشائع"];

export default function MaqamScreen() {
  const insets = useSafeAreaInsets();
  const bottom = Platform.OS === "web" ? 34 : 0;
  const [selectedMaqam, setSelectedMaqam] = useState("bayati");

  const handleSelect = (id: string) => {
    setSelectedMaqam(id);
    Haptics.selectionAsync();
  };

  const selectedData = MAQAMAT.find(m => m.id === selectedMaqam);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 + bottom }]}
      showsVerticalScrollIndicator={false}
    >
      {/* Wheel */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>🎼 اختر المقام</Text>
        <View style={{ alignItems: "center" }}>
          <MaqamWheel selected={selectedMaqam} onSelect={handleSelect} />
        </View>
      </View>

      {/* List */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>قائمة المقامات</Text>
        <View style={{ gap: 6 }}>
          {MAQAMAT.map(m => (
            <TouchableOpacity
              key={m.id}
              onPress={() => handleSelect(m.id)}
              style={[
                styles.maqamRow,
                {
                  backgroundColor: selectedMaqam === m.id ? m.color + "18" : "transparent",
                  borderLeftColor: selectedMaqam === m.id ? m.color : "#1a1a22",
                }
              ]}
            >
              <View style={[styles.colorDot, { backgroundColor: m.color }]} />
              <View style={{ flex: 1 }}>
                <Text style={{ color: selectedMaqam === m.id ? m.color : "#888", fontSize: 14, fontWeight: "600" }}>
                  مقام {m.name}
                </Text>
                <Text style={{ color: "#444", fontSize: 10, marginTop: 2 }}>{m.feel}</Text>
              </View>
              <Text style={{ color: "#333", fontSize: 10 }}>{m.freq} Hz</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Selected maqam detail */}
      {selectedData && (
        <View style={[styles.detailCard, { backgroundColor: selectedData.color + "12", borderColor: selectedData.color + "44" }]}>
          <Text style={{ fontSize: 18, color: selectedData.color, fontWeight: "700", marginBottom: 10 }}>
            مقام {selectedData.name}
          </Text>
          <Text style={{ color: "#888", fontSize: 12, marginBottom: 12, textAlign: "right" }}>
            {selectedData.feel}
          </Text>
          <WaveformVisualizer active color={selectedData.color} height={40} />
          <View style={styles.tagRow}>
            {TAGS.map(tag => (
              <View key={tag} style={[styles.tag, { backgroundColor: selectedData.color + "22" }]}>
                <Text style={{ color: selectedData.color, fontSize: 10 }}>{tag}</Text>
              </View>
            ))}
          </View>
          <View style={styles.freqBadge}>
            <Text style={{ color: "#444", fontSize: 10 }}>التردد الأساسي</Text>
            <Text style={{ color: selectedData.color, fontSize: 16, fontWeight: "700" }}>
              {selectedData.freq} Hz
            </Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#070709" },
  content: { padding: 16 },
  card: { backgroundColor: "#0d0d12", borderWidth: 1, borderColor: "#1a1a22", borderRadius: 12, padding: 14, marginBottom: 12 },
  cardLabel: { fontSize: 11, color: "#666", marginBottom: 10 },
  maqamRow: { flexDirection: "row", alignItems: "center", gap: 10, padding: 10, borderRadius: 8, borderLeftWidth: 3 },
  colorDot: { width: 8, height: 8, borderRadius: 4 },
  detailCard: { borderWidth: 1, borderRadius: 12, padding: 14, marginBottom: 12 },
  tagRow: { flexDirection: "row", gap: 6, marginTop: 10, flexWrap: "wrap" },
  tag: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  freqBadge: { marginTop: 12, alignItems: "center" },
});
