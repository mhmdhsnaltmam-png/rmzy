import React, { useEffect, useRef, useState } from "react";
import { View } from "react-native";
import Svg, { Path, Line } from "react-native-svg";

interface Props {
  active: boolean;
  color?: string;
  height?: number;
}

export function WaveformVisualizer({ active, color = "#C8963E", height = 48 }: Props) {
  const [pathD, setPathD] = useState("");
  const timeRef = useRef(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const W = 300;
  const H = height;

  const buildPath = (t: number) => {
    const steps = 80;
    const pts: string[] = [];
    for (let i = 0; i <= steps; i++) {
      const x = (i / steps) * W;
      const p = i / steps;
      const wave =
        Math.sin(p * 14 + t) * 0.4 +
        Math.sin(p * 7 + t * 1.3) * 0.3 +
        Math.sin(p * 21 + t * 0.7) * 0.15 +
        Math.sin(p * 3.5 + t * 2.1) * 0.15;
      const amp = (H / 2) * 0.75;
      const y = H / 2 + wave * amp;
      pts.push(i === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : `L ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return pts.join(" ");
  };

  useEffect(() => {
    if (!active) {
      setPathD(`M 0 ${H / 2} L ${W} ${H / 2}`);
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    timerRef.current = setInterval(() => {
      timeRef.current += 0.05;
      setPathD(buildPath(timeRef.current));
    }, 33);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [active, height]);

  return (
    <View style={{ width: "100%", height }}>
      <Svg width="100%" height={height} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        <Path
          d={pathD || `M 0 ${H / 2} L ${W} ${H / 2}`}
          stroke={active ? color : color + "44"}
          strokeWidth={active ? 2 : 1.5}
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </Svg>
    </View>
  );
}
