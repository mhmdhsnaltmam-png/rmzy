import React from "react";
import { View, Text, StyleSheet } from "react-native";

type Status = "idle" | "active" | "done" | "error";

interface Stage {
  id: string;
  label: string;
  sub: string;
  icon: string;
}

interface Props {
  stage: Stage;
  status: Status;
  progress: number;
}

const STATUS_COLORS = {
  idle:  { bg: "#ffffff08", border: "#ffffff11", dot: "#444", text: "#bbb" },
  active:{ bg: "#C8963E18", border: "#C8963E88", dot: "#C8963E", text: "#C8963E" },
  done:  { bg: "#2E8B7A18", border: "#2E8B7A88", dot: "#2E8B7A", text: "#2E8B7A" },
  error: { bg: "#A8444418", border: "#A8444488", dot: "#A84444", text: "#A84444" },
};

export function PipelineStageCard({ stage, status, progress }: Props) {
  const c = STATUS_COLORS[status] || STATUS_COLORS.idle;
  return (
    <View style={[styles.card, { backgroundColor: c.bg, borderColor: c.border }]}>
      {status === "active" && (
        <View style={[styles.progressBar, { width: `${progress}%` as any }]} />
      )}
      <Text style={styles.icon}>{stage.icon}</Text>
      <View style={styles.info}>
        <Text style={[styles.label, { color: c.text }]}>{stage.label}</Text>
        <Text style={styles.sub}>{stage.sub}</Text>
      </View>
      <View style={[styles.dot, {
        backgroundColor: c.dot,
        shadowColor: status === "active" ? c.dot : "transparent",
        shadowRadius: status === "active" ? 4 : 0,
        shadowOpacity: status === "active" ? 1 : 0,
      }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderRadius: 8,
    padding: 10,
    overflow: "hidden",
    position: "relative",
  },
  progressBar: {
    position: "absolute",
    left: 0,
    top: 0,
    height: "100%",
    backgroundColor: "#C8963E12",
  },
  icon: {
    fontSize: 16,
  },
  info: {
    flex: 1,
  },
  label: {
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 0.3,
  },
  sub: {
    fontSize: 9,
    color: "#555",
    marginTop: 1,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    flexShrink: 0,
  },
});
