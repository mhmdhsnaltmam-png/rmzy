import React, { useRef } from "react";
import { PanResponder, View, Text, StyleSheet } from "react-native";
import Svg, { Circle, Line } from "react-native-svg";

interface Props {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  color?: string;
}

export function Knob({ label, value, onChange, min = 0, max = 100, color = "#C8963E" }: Props) {
  const dragRef = useRef<{ startY: number; startVal: number } | null>(null);
  const angle = -135 + (value / (max - min)) * 270;
  const R = 18;
  const cx = 26, cy = 26;
  const circumference = 2 * Math.PI * R;
  const trackArc = 0.75 * circumference;
  const valueArc = (value / (max - min)) * 0.75 * circumference;
  const offset = -0.125 * circumference;

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (_, gs) => {
        dragRef.current = { startY: gs.y0, startVal: value };
      },
      onPanResponderMove: (_, gs) => {
        if (!dragRef.current) return;
        const delta = ((dragRef.current.startY - gs.moveY) / 150) * (max - min);
        const next = Math.max(min, Math.min(max, dragRef.current.startVal + delta));
        onChange(next);
      },
      onPanResponderRelease: () => {
        dragRef.current = null;
      },
    })
  ).current;

  const ptrX = cx + 13 * Math.cos(((angle - 90) * Math.PI) / 180);
  const ptrY = cy + 13 * Math.sin(((angle - 90) * Math.PI) / 180);

  return (
    <View style={styles.container} {...panResponder.panHandlers}>
      <Svg width={52} height={52}>
        <Circle cx={cx} cy={cy} r={22} fill="#111" stroke="#222" strokeWidth={2} />
        <Circle cx={cx} cy={cy} r={R} fill="#0a0a0f" stroke={color + "44"} strokeWidth={1.5} />
        <Circle
          cx={cx} cy={cy} r={R} fill="none"
          stroke={color + "22"} strokeWidth={3}
          strokeDasharray={`${trackArc} ${circumference}`}
          strokeDashoffset={offset}
          strokeLinecap="round"
        />
        <Circle
          cx={cx} cy={cy} r={R} fill="none"
          stroke={color} strokeWidth={3}
          strokeDasharray={`${valueArc} ${circumference}`}
          strokeDashoffset={offset}
          strokeLinecap="round"
        />
        <Line
          x1={cx} y1={cy}
          x2={ptrX} y2={ptrY}
          stroke={color} strokeWidth={2} strokeLinecap="round"
        />
        <Circle cx={cx} cy={cy} r={3} fill={color} />
      </Svg>
      <View style={styles.label}>
        <Text style={[styles.value, { color: "#ccc" }]}>{Math.round(value)}</Text>
        <Text style={[styles.labelText, { color: "#888" }]}>{label}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    gap: 4,
  },
  label: {
    alignItems: "center",
  },
  value: {
    fontSize: 10,
    fontWeight: "600",
  },
  labelText: {
    fontSize: 9,
    textAlign: "center",
  },
});
