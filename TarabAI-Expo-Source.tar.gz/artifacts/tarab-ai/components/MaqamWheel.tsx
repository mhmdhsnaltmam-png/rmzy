import React from "react";
import { View } from "react-native";
import Svg, { Path, Circle, Text as SvgText, G } from "react-native-svg";

const MAQAMAT = [
  { id: "bayati",   name: "بياتي",   color: "#C8963E" },
  { id: "hijaz",    name: "حجاز",    color: "#9B4E8E" },
  { id: "rast",     name: "راست",    color: "#3A86A8" },
  { id: "saba",     name: "صبا",     color: "#5C8A3C" },
  { id: "sikah",    name: "سيكا",    color: "#A84444" },
  { id: "nahawand", name: "نهاوند",  color: "#6B5CA5" },
  { id: "ajam",     name: "عجم",     color: "#2E8B7A" },
];

interface Props {
  selected: string;
  onSelect: (id: string) => void;
}

export function MaqamWheel({ selected, onSelect }: Props) {
  const cx = 110, cy = 110, r = 82, innerR = 40;
  const n = MAQAMAT.length;

  const selectedMaqam = MAQAMAT.find(m => m.id === selected);

  return (
    <Svg viewBox="0 0 220 220" width="100%" height={220}>
      {MAQAMAT.map((m, i) => {
        const angle = (i / n) * 2 * Math.PI - Math.PI / 2;
        const nextAngle = ((i + 1) / n) * 2 * Math.PI - Math.PI / 2;
        const x1o = cx + r * Math.cos(angle);
        const y1o = cy + r * Math.sin(angle);
        const x2o = cx + r * Math.cos(nextAngle);
        const y2o = cy + r * Math.sin(nextAngle);
        const x1i = cx + innerR * Math.cos(angle);
        const y1i = cy + innerR * Math.sin(angle);
        const x2i = cx + innerR * Math.cos(nextAngle);
        const y2i = cy + innerR * Math.sin(nextAngle);
        const mid = (angle + nextAngle) / 2;
        const tx = cx + ((r + innerR) / 2) * Math.cos(mid);
        const ty = cy + ((r + innerR) / 2) * Math.sin(mid);
        const isSelected = selected === m.id;
        const d = `M ${x1i.toFixed(2)} ${y1i.toFixed(2)} L ${x1o.toFixed(2)} ${y1o.toFixed(2)} A ${r} ${r} 0 0 1 ${x2o.toFixed(2)} ${y2o.toFixed(2)} L ${x2i.toFixed(2)} ${y2i.toFixed(2)} A ${innerR} ${innerR} 0 0 0 ${x1i.toFixed(2)} ${y1i.toFixed(2)}`;
        return (
          <G key={m.id} onPress={() => onSelect(m.id)}>
            <Path
              d={d}
              fill={isSelected ? m.color : m.color + "33"}
              stroke={m.color}
              strokeWidth={isSelected ? 2 : 0.8}
            />
            <SvgText
              x={tx}
              y={ty}
              textAnchor="middle"
              alignmentBaseline="middle"
              fontSize={isSelected ? 10 : 8.5}
              fill={isSelected ? "#fff" : m.color}
              fontWeight={isSelected ? "bold" : "normal"}
            >
              {m.name}
            </SvgText>
          </G>
        );
      })}
      <Circle cx={cx} cy={cy} r={innerR - 2} fill="#0a0a0f" />
      <SvgText x={cx} y={cy - 8} textAnchor="middle" alignmentBaseline="middle" fontSize={9} fill="#666">
        مقام
      </SvgText>
      <SvgText
        x={cx}
        y={cy + 8}
        textAnchor="middle"
        alignmentBaseline="middle"
        fontSize={11}
        fill="#C8963E"
        fontWeight="bold"
      >
        {selectedMaqam?.name ?? "—"}
      </SvgText>
    </Svg>
  );
}
